package thelostsoulsyeyeye.client.render;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.client.ClientFractureState;
import thelostsoulsyeyeye.fracture.FractureTimeline;
import thelostsoulsyeyeye.world.TheirWorld;

/**
 * Overworld sky corruption. As the per-player progress climbs from 0 to 1 we paint more and more wrongness over
 * the vanilla sky (after it has been drawn, before terrain covers it): a sickly tint, a black sun and moon, a
 * network of cracks that creeps outward, a dark void at its centre, and an Eye that opens and watches you.
 * When the fracture cinematic runs, it adds the crack, the shards and the tentacles on top.
 */
public final class SkyEffects {
	private SkyEffects() {}

	private static final ResourceLocation CRACKS = Thelostsouls.id("textures/environment/sky_cracks.png");
	private static final ResourceLocation VOID = Thelostsouls.id("textures/environment/sky_void.png");
	private static final ResourceLocation DARK_SUN = Thelostsouls.id("textures/environment/dark_sun.png");
	private static final ResourceLocation EYE = Thelostsouls.id("textures/environment/eye.png");
	private static final ResourceLocation PUPIL = Thelostsouls.id("textures/environment/eye_pupil.png");
	private static final Vector3f UP = new Vector3f(0.0F, 1.0F, 0.0F);

	public static void renderOverworld(WorldRenderContext context) {
		ClientLevel level = context.world();
		if (level == null || level.dimension() != Level.OVERWORLD) {
			return;
		}
		boolean event = ClientFractureState.isEventActive();
		float p = ClientFractureState.progress();
		if (p < 0.1F && !event) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		float partial = context.tickDelta();
		float time = level.getGameTime() + partial;
		float t = event ? ClientFractureState.eventTime(partial) : -1.0F;
		float radius = Math.max(128.0F, mc.options.renderDistance().get() * 16.0F * 2.0F);
		Matrix4f m = context.matrixStack().last().pose();

		// --- how much of each effect to show
		float tintA = RenderUtil.smooth(0.1F, 0.9F, p) * 0.5F * (0.85F + 0.15F * Mth.sin(time * 0.03F));
		float tr = 0.40F;
		float tg = 0.08F;
		float tb = 0.28F;
		float crackSpread = 0.85F * RenderUtil.smooth(0.5F, 1.0F, p);
		float crackA = 0.75F * RenderUtil.smooth(0.45F, 0.95F, p) * (0.7F + 0.3F * Mth.sin(time * 0.05F));
		float voidA = 0.5F * RenderUtil.smooth(0.82F, 1.0F, p);
		float voidHalf = 0.10F;
		float sunA = RenderUtil.smooth(0.4F, 0.75F, p);
		float eyeA = RenderUtil.smooth(0.7F, 0.92F, p);

		if (event) {
			float dark = RenderUtil.smooth(0.0F, FractureTimeline.CRACK, t);
			tr = Mth.lerp(dark, tr, 0.07F);
			tg = Mth.lerp(dark, tg, 0.0F);
			tb = Mth.lerp(dark, tb, 0.06F);
			tintA = Math.max(tintA, 0.9F * dark);
			float burst = RenderUtil.smooth(FractureTimeline.CRACK, FractureTimeline.CRACK + 14, t);
			crackSpread = Math.max(crackSpread, burst);
			crackA = Math.max(crackA, Math.max(0.4F * dark, burst));
			voidA = Math.max(voidA, RenderUtil.smooth(FractureTimeline.CRACK, FractureTimeline.CRACK + 10, t));
			voidHalf = Math.max(voidHalf, 0.10F + 0.26F * RenderUtil.smooth(FractureTimeline.CRACK, FractureTimeline.CRACK + 40, t));
		}

		RenderUtil.begin3D();

		// 1. tint everything (stronger toward the horizon, which is where the vanilla fog would otherwise stay pale)
		BufferBuilder b = RenderUtil.begin(RenderUtil.SOLID);
		RenderUtil.cap(b, m, UP, radius, 1.85F, 8, 24, 0.0F, RenderUtil.a255(tr), RenderUtil.a255(tg), RenderUtil.a255(tb), RenderUtil.a255(tintA), 0.6F);
		float flicker = ClientFractureState.flicker();
		if (flicker > 0.01F) {
			RenderUtil.cap(b, m, UP, radius, 1.85F, 8, 24, 0.0F, 200, 255, 230, RenderUtil.a255(flicker), 0.0F);
		}
		RenderUtil.end(b);

		// 2. a black sun, and a black moon
		if (sunA > 0.01F) {
			float angle = level.getTimeOfDay(partial) * Mth.TWO_PI;
			Vector3f sun = new Vector3f(-Mth.sin(angle), Mth.cos(angle), 0.0F);
			Vector3f moon = new Vector3f(sun).negate();
			b = RenderUtil.begin(DARK_SUN);
			RenderUtil.billboard(b, m, sun, radius, 0.85F, 0.85F, 0.0F, 0.0F, 255, 255, 255, RenderUtil.a255(sunA));
			RenderUtil.billboard(b, m, moon, radius, 0.6F, 0.6F, 0.0F, 0.0F, 255, 255, 255, RenderUtil.a255(sunA * 0.85F));
			RenderUtil.end(b);
		}

		// 3. the Eye
		if (eyeA > 0.01F) {
			drawEye(m, radius, context.camera().getLookVector(), time, eyeA, 1.0F);
		}

		// 4. cracks spreading outward from the wound
		if (crackA > 0.01F) {
			float maxAngle = Mth.lerp(crackSpread, 0.35F, 1.75F);
			b = RenderUtil.begin(CRACKS);
			RenderUtil.cap(b, m, ClientFractureState.CRACK_DIR, radius * 0.99F, maxAngle, 14, 36, 0.0F, 255, 255, 255, RenderUtil.a255(crackA), 0.0F);
			RenderUtil.end(b);
		}

		// 5. the wound itself
		if (voidA > 0.01F) {
			b = RenderUtil.begin(VOID);
			RenderUtil.billboard(b, m, ClientFractureState.CRACK_DIR, radius * 0.99F, voidHalf, voidHalf, 0.0F, 0.0F, 255, 255, 255, RenderUtil.a255(voidA));
			RenderUtil.end(b);
		}

		// 6. tentacles and shards
		if (event) {
			FractureCinematic.render(m, radius, t, ClientFractureState.eventSeed(), ClientFractureState.CRACK_DIR, time);
		}

		RenderUtil.end3D();
	}

	/**
	 * The Eye. It blinks every few seconds, and its pupil slides toward wherever you are looking.
	 * Used in the Overworld (small) and in Their World (huge).
	 */
	public static void drawEye(Matrix4f m, float radius, Vector3f look, float time, float alpha, float scale) {
		Vector3f dir = ClientFractureState.EYE_DIR;
		float cycle = time % 190.0F;
		float open = cycle < 10.0F ? Math.abs(cycle - 5.0F) / 5.0F : 1.0F;
		open = Mth.clamp(open, 0.03F, 1.0F);

		Vector3f ref = new Vector3f(0.0F, 1.0F, 0.0F);
		Vector3f right = new Vector3f(dir).cross(ref).normalize();
		float lookRight = new Vector3f(look).dot(right);
		float pupilOffset = Mth.clamp(lookRight * 0.4F, -0.12F, 0.12F) * scale;

		BufferBuilder b = RenderUtil.begin(EYE);
		RenderUtil.billboard(b, m, dir, radius * 0.98F, 0.34F * scale, 0.17F * scale * open, 0.0F, 0.0F, 255, 255, 255, RenderUtil.a255(alpha));
		RenderUtil.end(b);
		b = RenderUtil.begin(PUPIL);
		RenderUtil.billboard(b, m, dir, radius * 0.97F, 0.16F * scale, 0.16F * scale * open, pupilOffset, 0.0F, 255, 255, 255, RenderUtil.a255(alpha));
		RenderUtil.end(b);
	}

	/** Closes in the fog while the sky is wrong, and when the tentacle comes for you. Runs after vanilla has set fog. */
	public static void applyFog(WorldRenderContext context) {
		ClientLevel level = context.world();
		if (level == null) {
			return;
		}
		if (level.dimension() == TheirWorld.LEVEL_KEY) {
			RenderSystem.setShaderFogStart(2.0F);
			RenderSystem.setShaderFogEnd(Math.min(RenderSystem.getShaderFogEnd(), 54.0F));
			return;
		}
		if (level.dimension() != Level.OVERWORLD) {
			return;
		}
		float k = RenderUtil.smooth(0.55F, 1.0F, ClientFractureState.progress()) * 0.55F;
		if (ClientFractureState.isEventActive()) {
			float t = ClientFractureState.eventTime(context.tickDelta());
			k = Math.max(k, 0.8F * RenderUtil.smooth(0.0F, FractureTimeline.CRACK, t));
		}
		if (k <= 0.01F) {
			return;
		}
		RenderSystem.setShaderFogStart(Mth.lerp(k, RenderSystem.getShaderFogStart(), 4.0F));
		RenderSystem.setShaderFogEnd(Mth.lerp(k, RenderSystem.getShaderFogEnd(), 48.0F));
		float[] c = RenderSystem.getShaderFogColor();
		RenderSystem.setShaderFogColor(Mth.lerp(k, c[0], 0.20F), Mth.lerp(k, c[1], 0.04F), Mth.lerp(k, c[2], 0.14F));
	}
}
