package thelostsoulsyeyeye.client.render;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import thelostsoulsyeyeye.Thelostsouls;

/**
 * Immediate-mode helpers for drawing things "in the sky": every position is a direction from the camera
 * scaled by a radius, in camera-relative world space (the matrix stack Fabric hands us has the camera's
 * rotation but no translation, which is exactly how vanilla draws its own sky).
 */
public final class RenderUtil {
	private RenderUtil() {}

	public static final ResourceLocation SOLID = Thelostsouls.id("textures/environment/solid.png");

	public static float smooth(float edge0, float edge1, float x) {
		float t = Mth.clamp((x - edge0) / (edge1 - edge0), 0.0F, 1.0F);
		return t * t * (3.0F - 2.0F * t);
	}

	public static int a255(float alpha) {
		return Mth.clamp((int) (alpha * 255.0F), 0, 255);
	}

	/** Translucent, double-sided, depth-tested but not depth-writing: the state vanilla uses for sky layers. */
	public static void begin3D() {
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableCull();
		RenderSystem.enableDepthTest();
		RenderSystem.depthMask(false);
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
	}

	public static void end3D() {
		RenderSystem.depthMask(true);
		RenderSystem.enableCull();
		RenderSystem.disableBlend();
		RenderSystem.enableDepthTest();
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
	}

	public static BufferBuilder begin(ResourceLocation texture) {
		RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
		RenderSystem.setShaderTexture(0, texture);
		BufferBuilder builder = Tesselator.getInstance().getBuilder();
		builder.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
		return builder;
	}

	public static void end(BufferBuilder builder) {
		BufferUploader.drawWithShader(builder.end());
	}

	public static void vertex(BufferBuilder b, Matrix4f m, float x, float y, float z, float u, float v, int r, int g, int bl, int a) {
		b.vertex(m, x, y, z).uv(u, v).color(r, g, bl, a).endVertex();
	}

	/**
	 * A flat picture hanging in the sky, facing the viewer.
	 * halfW/halfH and the offsets are fractions of radius; offRight/offUp slide the picture along its own axes.
	 */
	public static void billboard(BufferBuilder b, Matrix4f m, Vector3f dir, float radius, float halfW, float halfH,
			float offRight, float offUp, int r, int g, int bl, int a) {
		Vector3f f = new Vector3f(dir).normalize();
		Vector3f ref = Math.abs(f.y) > 0.98F ? new Vector3f(1.0F, 0.0F, 0.0F) : new Vector3f(0.0F, 1.0F, 0.0F);
		Vector3f right = new Vector3f(f).cross(ref).normalize();
		Vector3f up = new Vector3f(right).cross(f).normalize();
		float cx = f.x * radius + (right.x * offRight + up.x * offUp) * radius;
		float cy = f.y * radius + (right.y * offRight + up.y * offUp) * radius;
		float cz = f.z * radius + (right.z * offRight + up.z * offUp) * radius;
		float rw = halfW * radius;
		float rh = halfH * radius;
		vertex(b, m, cx - right.x * rw + up.x * rh, cy - right.y * rw + up.y * rh, cz - right.z * rw + up.z * rh, 0.0F, 0.0F, r, g, bl, a);
		vertex(b, m, cx + right.x * rw + up.x * rh, cy + right.y * rw + up.y * rh, cz + right.z * rw + up.z * rh, 1.0F, 0.0F, r, g, bl, a);
		vertex(b, m, cx + right.x * rw - up.x * rh, cy + right.y * rw - up.y * rh, cz + right.z * rw - up.z * rh, 1.0F, 1.0F, r, g, bl, a);
		vertex(b, m, cx - right.x * rw - up.x * rh, cy - right.y * rw - up.y * rh, cz - right.z * rw - up.z * rh, 0.0F, 1.0F, r, g, bl, a);
	}

	/**
	 * A spherical cap of the sky centred on {@code center}, reaching {@code maxAngle} radians away from it.
	 * The texture is projected straight down onto the cap (like looking at it from its pole), so a crack
	 * texture with its impact point in the middle of the image radiates from {@code center}. Enlarging
	 * maxAngle stretches the picture across more sky, so the cracks appear to spread.
	 * edgeBoost > 0 makes the rim more opaque than the middle (used to tint the horizon harder).
	 */
	public static void cap(BufferBuilder b, Matrix4f m, Vector3f center, float radius, float maxAngle, int rings, int segs,
			float uvRotation, int r, int g, int bl, int a, float edgeBoost) {
		Quaternionf q = new Quaternionf().rotationTo(0.0F, 1.0F, 0.0F, center.x, center.y, center.z);
		float sinMax = Mth.sin(Math.min(maxAngle, Mth.HALF_PI));
		float cu = Mth.cos(uvRotation);
		float su = Mth.sin(uvRotation);
		Vector3f tmp = new Vector3f();
		for (int i = 0; i < rings; i++) {
			float t0 = maxAngle * i / rings;
			float t1 = maxAngle * (i + 1) / rings;
			int a0 = Mth.clamp((int) (a * (1.0F + edgeBoost * (t0 / maxAngle - 0.5F))), 0, 255);
			int a1 = Mth.clamp((int) (a * (1.0F + edgeBoost * (t1 / maxAngle - 0.5F))), 0, 255);
			for (int j = 0; j < segs; j++) {
				float p0 = Mth.TWO_PI * j / segs;
				float p1 = Mth.TWO_PI * (j + 1) / segs;
				capVertex(b, m, q, tmp, radius, t0, p0, sinMax, cu, su, r, g, bl, a0);
				capVertex(b, m, q, tmp, radius, t0, p1, sinMax, cu, su, r, g, bl, a0);
				capVertex(b, m, q, tmp, radius, t1, p1, sinMax, cu, su, r, g, bl, a1);
				capVertex(b, m, q, tmp, radius, t1, p0, sinMax, cu, su, r, g, bl, a1);
			}
		}
	}

	private static void capVertex(BufferBuilder b, Matrix4f m, Quaternionf q, Vector3f tmp, float radius, float theta, float phi,
			float sinMax, float cu, float su, int r, int g, int bl, int a) {
		float sx = Mth.sin(theta) * Mth.cos(phi);
		float sz = Mth.sin(theta) * Mth.sin(phi);
		float sy = Mth.cos(theta);
		tmp.set(sx, sy, sz);
		q.transform(tmp);
		float ux = sx / sinMax;
		float uz = sz / sinMax;
		float u = 0.5F + 0.5F * (ux * cu - uz * su);
		float v = 0.5F + 0.5F * (ux * su + uz * cu);
		vertex(b, m, tmp.x * radius, tmp.y * radius, tmp.z * radius, u, v, r, g, bl, a);
	}

	/** A vertically graded dome (solid texture): colour blends from {@code top} to {@code horizon} by angle from zenith. */
	public static void gradientDome(BufferBuilder b, Matrix4f m, float radius, float maxAngle, int rings, int segs,
			float[] top, float[] horizon, float alpha, float curve) {
		Vector3f p = new Vector3f();
		for (int i = 0; i < rings; i++) {
			float t0 = maxAngle * i / rings;
			float t1 = maxAngle * (i + 1) / rings;
			float k0 = (float) Math.pow(t0 / maxAngle, curve);
			float k1 = (float) Math.pow(t1 / maxAngle, curve);
			for (int j = 0; j < segs; j++) {
				float p0 = Mth.TWO_PI * j / segs;
				float p1 = Mth.TWO_PI * (j + 1) / segs;
				gradVertex(b, m, p, radius, t0, p0, top, horizon, k0, alpha);
				gradVertex(b, m, p, radius, t0, p1, top, horizon, k0, alpha);
				gradVertex(b, m, p, radius, t1, p1, top, horizon, k1, alpha);
				gradVertex(b, m, p, radius, t1, p0, top, horizon, k1, alpha);
			}
		}
	}

	private static void gradVertex(BufferBuilder b, Matrix4f m, Vector3f p, float radius, float theta, float phi,
			float[] top, float[] horizon, float k, float alpha) {
		p.set(Mth.sin(theta) * Mth.cos(phi), Mth.cos(theta), Mth.sin(theta) * Mth.sin(phi));
		int r = a255(Mth.lerp(k, top[0], horizon[0]));
		int g = a255(Mth.lerp(k, top[1], horizon[1]));
		int bl = a255(Mth.lerp(k, top[2], horizon[2]));
		vertex(b, m, p.x * radius, p.y * radius, p.z * radius, 0.5F, 0.5F, r, g, bl, a255(alpha));
	}
}
