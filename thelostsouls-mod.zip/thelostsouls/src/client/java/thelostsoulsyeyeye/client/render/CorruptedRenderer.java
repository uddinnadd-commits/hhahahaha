package thelostsoulsyeyeye.client.render;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.entity.CorruptedEntity;

/** One renderer for all five creatures: textures/entity/NAME.png plus a NAME_glow.png emissive layer. */
public class CorruptedRenderer<T extends CorruptedEntity, M extends EntityModel<T>> extends MobRenderer<T, M> {
	private final ResourceLocation texture;

	public CorruptedRenderer(EntityRendererProvider.Context context, M model, String name, float shadowRadius) {
		super(context, model, shadowRadius);
		this.texture = Thelostsouls.id("textures/entity/" + name + ".png");
		this.addLayer(new GlowLayer<T, M>(this, Thelostsouls.id("textures/entity/" + name + "_glow.png")));
	}

	@Override
	public ResourceLocation getTextureLocation(T entity) {
		return this.texture;
	}
}
