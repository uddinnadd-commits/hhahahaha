package thelostsoulsyeyeye.client.model;

import net.minecraft.client.animation.AnimationDefinition;

import static thelostsoulsyeyeye.client.model.Anim.*;

/** Crawler: restless sniffing, and a heavy rear-up-and-slam attack. */
public final class CrawlerAnimations {
	private CrawlerAnimations() {}

	public static final AnimationDefinition IDLE = AnimationDefinition.Builder.withLength(2.4F).looping()
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.8F, 0, 18, 6), r(1.6F, 0, -18, -6), r(2.4F, 0, 0, 0)))
			.addAnimation("jaw", rot(snap(0.0F, 0, 0, 0), snap(1.0F, 0, 0, 0), snap(1.06F, 20, 0, 0), snap(1.14F, 2, 0, 0), snap(1.22F, 24, 0, 0), snap(1.3F, 0, 0, 0), snap(2.4F, 0, 0, 0)))
			.addAnimation("spine1", rot(r(0.0F, 0, 0, 0), r(1.2F, 0, 0, 14), r(2.4F, 0, 0, 0)))
			.build();

	public static final AnimationDefinition ATTACK = AnimationDefinition.Builder.withLength(0.7F)
			.addAnimation("body", rot(r(0.0F, 0, 0, 0), r(0.2F, 28, 0, 0), r(0.4F, -22, 0, 0), r(0.7F, 0, 0, 0)))
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.2F, -25, 0, 0), r(0.4F, 30, 0, 0), r(0.7F, 0, 0, 0)))
			.addAnimation("jaw", rot(r(0.0F, 0, 0, 0), r(0.2F, 80, 0, 0), r(0.4F, 0, 0, 0), r(0.7F, 0, 0, 0)))
			.addAnimation("left_arm", rot(r(0.0F, 0, 0, 0), r(0.2F, -45, 0, 0), r(0.4F, 40, 0, 0), r(0.7F, 0, 0, 0)))
			.addAnimation("left_stump", rot(r(0.0F, 0, 0, 0), r(0.2F, -45, 0, 0), r(0.4F, 40, 0, 0), r(0.7F, 0, 0, 0)))
			.addAnimation("right_arm", rot(r(0.0F, 0, 0, 0), r(0.2F, -45, 0, 0), r(0.4F, 40, 0, 0), r(0.7F, 0, 0, 0)))
			.addAnimation("right_stump", rot(r(0.0F, 0, 0, 0), r(0.2F, -45, 0, 0), r(0.4F, 40, 0, 0), r(0.7F, 0, 0, 0)))
			.build();
}
