package thelostsoulsyeyeye.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import thelostsoulsyeyeye.fracture.FractureManager;

/**
 * /lostsouls progress <0-100>   set how far along the sky is for yourself
 * /lostsouls fracture           play the cinematic right now (and get pulled in)
 * /lostsouls enter | leave      skip the cinematic and travel directly
 * /lostsouls reset              wipe your progress and trip count
 */
public final class ModCommands {
	private ModCommands() {}

	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(Commands.literal("lostsouls")
						.requires(source -> source.hasPermission(2))
						.then(Commands.literal("progress")
								.then(Commands.argument("percent", IntegerArgumentType.integer(0, 100))
										.executes(ctx -> {
											ServerPlayer player = ctx.getSource().getPlayerOrException();
											int percent = IntegerArgumentType.getInteger(ctx, "percent");
											FractureManager.setProgressPercent(ctx.getSource().getServer(), player, percent);
											return say(ctx.getSource(), "Sky progress set to " + percent + "%");
										})))
						.then(Commands.literal("fracture").executes(ctx -> {
							FractureManager.beginEvent(ctx.getSource().getPlayerOrException());
							return say(ctx.getSource(), "The sky is cracking...");
						}))
						.then(Commands.literal("enter").executes(ctx -> {
							FractureManager.enterTheirWorld(ctx.getSource().getServer(), ctx.getSource().getPlayerOrException());
							return 1;
						}))
						.then(Commands.literal("leave").executes(ctx -> {
							FractureManager.leaveTheirWorld(ctx.getSource().getServer(), ctx.getSource().getPlayerOrException());
							return 1;
						}))
						.then(Commands.literal("reset").executes(ctx -> {
							FractureManager.reset(ctx.getSource().getServer(), ctx.getSource().getPlayerOrException());
							return say(ctx.getSource(), "Progress reset");
						}))));
	}

	private static int say(CommandSourceStack source, String message) throws CommandSyntaxException {
		source.sendSuccess(() -> Component.literal(message), false);
		return 1;
	}
}
