package thelostsoulsyeyeye;

import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.ResourceLocation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import thelostsoulsyeyeye.command.ModCommands;
import thelostsoulsyeyeye.fracture.FractureManager;
import thelostsoulsyeyeye.registry.ModBlocks;
import thelostsoulsyeyeye.registry.ModEntities;
import thelostsoulsyeyeye.registry.ModFeatures;
import thelostsoulsyeyeye.registry.ModGameRules;
import thelostsoulsyeyeye.registry.ModItems;
import thelostsoulsyeyeye.registry.ModParticles;
import thelostsoulsyeyeye.registry.ModSounds;
import thelostsoulsyeyeye.world.TheirWorldDirector;

public class Thelostsouls implements ModInitializer {
	public static final String MOD_ID = "thelostsouls";

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// Registration order matters: sounds -> entities -> blocks -> items (items refer to the others).
		ModSounds.init();
		ModParticles.init();
		ModEntities.init();
		ModBlocks.init();
		ModItems.init();
		ModFeatures.init();
		ModGameRules.init();

		FractureManager.init();
		TheirWorldDirector.init();
		ModCommands.init();

		LOGGER.info("The sky is watching. (thelostsouls loaded)");
	}

	public static ResourceLocation id(String path) {
		return new ResourceLocation(MOD_ID, path);
	}
}
