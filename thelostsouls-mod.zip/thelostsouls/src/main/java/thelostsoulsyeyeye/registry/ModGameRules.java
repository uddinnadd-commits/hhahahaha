package thelostsoulsyeyeye.registry;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.world.level.GameRules;

public final class ModGameRules {
	private ModGameRules() {}

	/**
	 * Minutes of Overworld play until the sky cracks (per player). 0 disables the whole event.
	 * Try {@code /gamerule lostSoulsFractureMinutes 3} to see everything quickly.
	 */
	public static final GameRules.Key<GameRules.IntegerValue> FRACTURE_MINUTES =
			GameRuleRegistry.register("lostSoulsFractureMinutes", GameRules.Category.MISC, GameRuleFactory.createIntRule(40, 0));

	/** When false, Them stop spawning in Their World (handy for building / screenshots). */
	public static final GameRules.Key<GameRules.BooleanValue> HUNT =
			GameRuleRegistry.register("lostSoulsHunt", GameRules.Category.MOBS, GameRuleFactory.createBooleanRule(true));

	public static void init() {}
}
