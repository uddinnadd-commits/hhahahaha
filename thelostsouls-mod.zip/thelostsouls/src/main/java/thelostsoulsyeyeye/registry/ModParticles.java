package thelostsoulsyeyeye.registry;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import thelostsoulsyeyeye.Thelostsouls;

public final class ModParticles {
	private ModParticles() {}

	public static final SimpleParticleType GLASS_SHARD =
			Registry.register(BuiltInRegistries.PARTICLE_TYPE, Thelostsouls.id("glass_shard"), FabricParticleTypes.simple());

	public static void init() {}
}
