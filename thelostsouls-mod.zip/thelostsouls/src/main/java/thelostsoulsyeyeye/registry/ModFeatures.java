package thelostsoulsyeyeye.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.world.feature.DeadTreeFeature;
import thelostsoulsyeyeye.world.feature.MemoryHouseFeature;
import thelostsoulsyeyeye.world.feature.MemoryVaultFeature;
import thelostsoulsyeyeye.world.feature.ObeliskFeature;
import thelostsoulsyeyeye.world.feature.PlaygroundFeature;
import thelostsoulsyeyeye.world.feature.WaitingHallFeature;

/** Worldgen features. They are wired into Their World by the JSON in data/thelostsouls/worldgen. */
public final class ModFeatures {
	private ModFeatures() {}

	public static final Feature<NoneFeatureConfiguration> DEAD_TREE = register("dead_tree", new DeadTreeFeature());
	public static final Feature<NoneFeatureConfiguration> MEMORY_HOUSE = register("memory_house", new MemoryHouseFeature());
	public static final Feature<NoneFeatureConfiguration> PLAYGROUND = register("playground", new PlaygroundFeature());
	public static final Feature<NoneFeatureConfiguration> WAITING_HALL = register("waiting_hall", new WaitingHallFeature());
	public static final Feature<NoneFeatureConfiguration> OBELISK = register("obelisk", new ObeliskFeature());
	public static final Feature<NoneFeatureConfiguration> MEMORY_VAULT = register("memory_vault", new MemoryVaultFeature());

	private static <T extends Feature<?>> T register(String name, T feature) {
		return Registry.register(BuiltInRegistries.FEATURE, Thelostsouls.id(name), feature);
	}

	public static void init() {}
}
