package thelostsoulsyeyeye.registry;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.entity.CrawlerEntity;
import thelostsoulsyeyeye.entity.EchoHoundEntity;
import thelostsoulsyeyeye.entity.HollowWalkerEntity;
import thelostsoulsyeyeye.entity.RemnantEntity;
import thelostsoulsyeyeye.entity.StretchedEntity;

public final class ModEntities {
	private ModEntities() {}

	// --- Them: the hunters of Their World
	public static final EntityType<HollowWalkerEntity> HOLLOW_WALKER = register("hollow_walker",
			FabricEntityTypeBuilder.create(MobCategory.MONSTER, HollowWalkerEntity::new)
					.dimensions(EntityDimensions.fixed(0.7F, 2.5F)).trackRangeBlocks(96).build(),
			HollowWalkerEntity.createAttributes());

	public static final EntityType<CrawlerEntity> CRAWLER = register("crawler",
			FabricEntityTypeBuilder.create(MobCategory.MONSTER, CrawlerEntity::new)
					.dimensions(EntityDimensions.fixed(1.0F, 0.8F)).trackRangeBlocks(96).build(),
			CrawlerEntity.createAttributes());

	public static final EntityType<StretchedEntity> STRETCHED = register("stretched",
			FabricEntityTypeBuilder.create(MobCategory.MONSTER, StretchedEntity::new)
					.dimensions(EntityDimensions.fixed(0.6F, 3.4F)).trackRangeBlocks(128).build(),
			StretchedEntity.createAttributes());

	// --- dungeon guardians (not Them)
	public static final EntityType<EchoHoundEntity> ECHO_HOUND = register("echo_hound",
			FabricEntityTypeBuilder.create(MobCategory.MONSTER, EchoHoundEntity::new)
					.dimensions(EntityDimensions.fixed(0.9F, 0.9F)).trackRangeBlocks(64).build(),
			EchoHoundEntity.createAttributes());

	public static final EntityType<RemnantEntity> REMNANT = register("remnant",
			FabricEntityTypeBuilder.create(MobCategory.MONSTER, RemnantEntity::new)
					.dimensions(EntityDimensions.fixed(0.7F, 2.1F)).trackRangeBlocks(64).build(),
			RemnantEntity.createAttributes());

	private static <T extends LivingEntity> EntityType<T> register(String name, EntityType<T> type, AttributeSupplier.Builder attributes) {
		Registry.register(BuiltInRegistries.ENTITY_TYPE, Thelostsouls.id(name), type);
		FabricDefaultAttributeRegistry.register(type, attributes);
		return type;
	}

	/** Call once from the mod initializer so the static fields above get registered. */
	public static void init() {}
}
