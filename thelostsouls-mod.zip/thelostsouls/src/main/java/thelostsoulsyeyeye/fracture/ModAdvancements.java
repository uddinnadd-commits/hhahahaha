package thelostsoulsyeyeye.fracture;

import net.minecraft.advancements.Advancement;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import thelostsoulsyeyeye.Thelostsouls;

/** Awards the mod's "impossible trigger" advancements by name. Safe to call repeatedly. */
public final class ModAdvancements {
	private ModAdvancements() {}

	public static void award(ServerPlayer player, String name) {
		ResourceLocation id = Thelostsouls.id(name);
		Advancement advancement = player.server.getAdvancements().getAdvancement(id);
		if (advancement != null && !player.getAdvancements().getOrStartProgress(advancement).isDone()) {
			player.getAdvancements().award(advancement, "trigger");
		}
	}
}
