package thelostsoulsyeyeye.world;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import thelostsoulsyeyeye.entity.CorruptedEntity;
import thelostsoulsyeyeye.registry.ModEntities;
import thelostsoulsyeyeye.registry.ModGameRules;
import thelostsoulsyeyeye.registry.ModSounds;

/**
 * "They will hunt you." Natural biome spawning is far too sparse and too well-behaved for that, so inside
 * Their World this director keeps a pressure level around each player: it spawns Them out of sight,
 * already targeting the player, and plays distant whispers so the silence is never quite silent.
 * Switch it off with /gamerule lostSoulsHunt false.
 */
public final class TheirWorldDirector {
	private TheirWorldDirector() {}

	private static final Map<UUID, Long> ARRIVED_AT = new HashMap<>();

	public static void init() {
		ServerTickEvents.END_WORLD_TICK.register(TheirWorldDirector::tick);
	}

	public static void markArrival(ServerPlayer player) {
		ARRIVED_AT.put(player.getUUID(), player.serverLevel().getGameTime());
	}

	private static void tick(ServerLevel level) {
		if (level.dimension() != TheirWorld.LEVEL_KEY || level.getGameTime() % 40L != 0L) {
			return;
		}
		RandomSource random = level.getRandom();
		for (ServerPlayer player : level.players()) {
			if (player.isSpectator() || !player.isAlive()) {
				continue;
			}
			ambient(level, player, random);
			if (level.getDifficulty() != Difficulty.PEACEFUL && level.getGameRules().getBoolean(ModGameRules.HUNT)) {
				hunt(level, player, random);
			}
		}
	}

	private static void ambient(ServerLevel level, ServerPlayer player, RandomSource random) {
		if (random.nextInt(7) != 0) {
			return;
		}
		double angle = random.nextDouble() * Math.PI * 2.0D;
		double dist = 6.0D + random.nextDouble() * 10.0D;
		SoundEvent sound = random.nextInt(5) == 0 ? ModSounds.AMBIENT_SKY_SCREAM : ModSounds.AMBIENT_WHISPER_FAR;
		level.playSound(null, player.getX() + Math.cos(angle) * dist, player.getY() + 1.0D, player.getZ() + Math.sin(angle) * dist,
				sound, SoundSource.AMBIENT, 0.9F, 0.85F + random.nextFloat() * 0.3F);
	}

	private static void hunt(ServerLevel level, ServerPlayer player, RandomSource random) {
		long since = level.getGameTime() - ARRIVED_AT.getOrDefault(player.getUUID(), level.getGameTime());
		int desired = 3 + Math.min(3, (int) (since / 4800L)) + (level.getDifficulty() == Difficulty.HARD ? 2 : 0);
		List<CorruptedEntity> nearby = level.getEntitiesOfClass(CorruptedEntity.class, player.getBoundingBox().inflate(72.0D), CorruptedEntity::isThem);
		if (nearby.size() >= desired) {
			return;
		}
		Vec3 look = player.getLookAngle();
		for (int attempt = 0; attempt < 10; attempt++) {
			double angle = random.nextDouble() * Math.PI * 2.0D;
			double dist = 26.0D + random.nextDouble() * 18.0D;
			int x = Mth.floor(player.getX() + Math.cos(angle) * dist);
			int z = Mth.floor(player.getZ() + Math.sin(angle) * dist);
			if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
				continue;
			}
			// prefer spawning behind or beside the player, only settle for "in front" on the last attempts
			Vec3 to = new Vec3(x - player.getX(), 0.0D, z - player.getZ()).normalize();
			if (attempt < 7 && look.dot(to) > 0.35D) {
				continue;
			}
			int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
			BlockPos pos = new BlockPos(x, y, z);
			if (!level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
				continue;
			}
			EntityType<? extends CorruptedEntity> type = pickType(random);
			CorruptedEntity entity = type.create(level);
			if (entity == null) {
				continue;
			}
			entity.moveTo(x + 0.5D, y, z + 0.5D, random.nextFloat() * 360.0F, 0.0F);
			if (!level.noCollision(entity)) {
				continue;
			}
			entity.setTarget(player);
			level.addFreshEntity(entity);
			return;
		}
	}

	private static EntityType<? extends CorruptedEntity> pickType(RandomSource random) {
		int roll = random.nextInt(100);
		if (roll < 50) {
			return ModEntities.HOLLOW_WALKER;
		}
		if (roll < 78) {
			return ModEntities.CRAWLER;
		}
		return ModEntities.STRETCHED;
	}
}
