package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Memory of play: a swing set with one swing broken, a lopsided seesaw, a sandpit, and Jun's warning. */
public class PlaygroundFeature extends Feature<NoneFeatureConfiguration> {
	public PlaygroundFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		StructureBuilder b = new StructureBuilder(context.level(), context.origin(), context.random());
		if (!b.groundOk(-6, -4, 6, 4, 2)) {
			return false;
		}
		b.terraform(-6, -4, 6, 4, 8);
		b.clear(-6, 0, -4, 6, 6, 4);

		// sand under the swings
		for (int x = -5; x <= 5; x++) {
			for (int z = -2; z <= 2; z++) {
				b.set(x, -1, z, b.chance(0.85F) ? Blocks.SAND : Blocks.DIRT);
			}
		}

		// frame: two posts and a beam
		BlockState beam = Blocks.DARK_OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);
		for (int y = 0; y <= 4; y++) {
			b.set(-4, y, 0, Blocks.STRIPPED_DARK_OAK_LOG);
			b.set(4, y, 0, Blocks.STRIPPED_DARK_OAK_LOG);
		}
		for (int x = -4; x <= 4; x++) {
			b.set(x, 4, 0, beam);
		}

		// swing one: intact, hanging perfectly still
		for (int y = 1; y <= 3; y++) {
			b.set(-2, y, 0, Blocks.CHAIN);
		}
		b.set(-2, 0, 0, Blocks.DARK_OAK_SLAB);
		// swing two: a chain snapped, the seat lying on its side in the sand
		b.set(1, 3, 0, Blocks.CHAIN);
		b.set(1, 2, 0, Blocks.CHAIN);
		b.set(2, 0, 1, Blocks.DARK_OAK_SLAB);

		// seesaw, one end up
		BlockState top = Blocks.DARK_OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP);
		for (int x = -3; x <= 3; x++) {
			if (x < 0) {
				b.set(x, 0, 3, top);
			} else if (x > 0) {
				b.set(x, 0, 3, Blocks.DARK_OAK_SLAB);
			}
		}
		b.set(0, 0, 3, Blocks.COBBLESTONE_WALL);

		b.wallSign(3, 2, 0, Direction.WEST, "I'M STILL", "WAITING", "", "- the small one");
		b.lectern(-5, 0, -3, Direction.EAST, MemoryLore.book(MemoryLore.THEM));
		if (b.chance(0.8F)) {
			b.set(-3, 3, 0, Blocks.COBWEB);
		}
		if (b.chance(0.8F)) {
			b.set(3, 3, 0, Blocks.COBWEB);
		}
		for (int i = 0; i < 6; i++) {
			int x = b.random.nextInt(13) - 6;
			int z = b.random.nextInt(9) - 4;
			if (b.get(x, 0, z).isAir() && !b.get(x, -1, z).isAir()) {
				b.set(x, 0, z, Blocks.DEAD_BUSH);
			}
		}
		return true;
	}
}
