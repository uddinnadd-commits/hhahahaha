package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Memory of the dead: a tall obelisk burning soul-fire, ringed by graves with the names of the guided. */
public class ObeliskFeature extends Feature<NoneFeatureConfiguration> {
	private static final String[] NAMES = {"MARA", "ELIAS", "NOOR", "THE SMALL ONE", "JUN", "ADA", "IVO", "SENNA", "DESMOND", "LIN", "THEO", "???"};

	public ObeliskFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		StructureBuilder b = new StructureBuilder(context.level(), context.origin(), context.random());
		if (!b.groundOk(-8, -8, 8, 8, 3)) {
			return false;
		}
		b.terraform(-8, -8, 8, 8, 14);
		b.clear(-8, 0, -8, 8, 14, 8);

		// stepped base
		b.fill(-2, -1, -2, 2, -1, 2, Blocks.POLISHED_BLACKSTONE_BRICKS);
		b.fill(-1, 0, -1, 1, 0, 1, Blocks.POLISHED_BLACKSTONE_BRICKS);
		// the shaft
		for (int y = 1; y <= 9; y++) {
			b.set(0, y, 0, y % 3 == 0 ? Blocks.CHISELED_POLISHED_BLACKSTONE : Blocks.POLISHED_BLACKSTONE);
		}
		b.set(0, 10, 0, Blocks.SOUL_LANTERN);
		for (int sx : new int[]{-2, 2}) {
			for (int sz : new int[]{-2, 2}) {
				b.set(sx, 0, sz, Blocks.SOUL_CAMPFIRE);
			}
		}
		b.lectern(0, 0, -3, Direction.NORTH, MemoryLore.book(MemoryLore.THE_SKY));

		// the graves
		int count = NAMES.length;
		for (int i = 0; i < count; i++) {
			double angle = (Math.PI * 2.0D) * i / count + (b.random.nextDouble() - 0.5D) * 0.3D;
			double radius = 5.0D + b.random.nextInt(3);
			int gx = (int) Math.round(Math.cos(angle) * radius);
			int gz = (int) Math.round(Math.sin(angle) * radius);
			Direction out = Direction.getNearest(gx, 0, gz);
			b.set(gx, 0, gz, Blocks.DEEPSLATE_BRICKS);
			b.set(gx, 1, gz, Blocks.DEEPSLATE_BRICK_SLAB);
			b.wallSign(gx + out.getStepX(), 0, gz + out.getStepZ(), out, "HERE LIES", NAMES[i], "WAITING", "");
		}
		return true;
	}
}
