package thelostsoulsyeyeye.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import thelostsoulsyeyeye.Thelostsouls;

/** Constants and helpers for the custom dimension (data/thelostsouls/dimension/their_world.json). */
public final class TheirWorld {
	private TheirWorld() {}

	public static final ResourceKey<Level> LEVEL_KEY = ResourceKey.create(Registries.DIMENSION, Thelostsouls.id("their_world"));

	public static boolean isIn(Level level) {
		return level.dimension() == LEVEL_KEY;
	}

	/**
	 * Finds somewhere to stand near the given column: bare dirt (not a tree top), with two blocks of air above.
	 * The player lands at the same x/z they were standing on in the Overworld, as if the world had been
	 * overwritten right where they were.
	 */
	public static BlockPos findSpawn(ServerLevel level, int x, int z) {
		BlockPos fallback = null;
		for (int r = 0; r <= 40; r += 4) {
			int steps = r == 0 ? 1 : 8;
			for (int i = 0; i < steps; i++) {
				double angle = (Math.PI * 2.0D) * i / steps;
				int px = x + (int) Math.round(Math.cos(angle) * r);
				int pz = z + (int) Math.round(Math.sin(angle) * r);
				level.getChunk(px >> 4, pz >> 4); // force generation
				int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, px, pz);
				BlockPos pos = new BlockPos(px, y, pz);
				if (fallback == null) {
					fallback = pos;
				}
				if (level.getBlockState(pos.below()).is(BlockTags.DIRT) && level.getBlockState(pos).isAir() && level.getBlockState(pos.above()).isAir()) {
					return pos;
				}
			}
		}
		return fallback;
	}
}
