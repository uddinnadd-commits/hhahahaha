package thelostsoulsyeyeye.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** A plain item that carries an italic lore line in its tooltip. */
public class LoreItem extends Item {
	private final String loreKey;

	public LoreItem(Properties properties, String loreKey) {
		super(properties);
		this.loreKey = loreKey;
	}

	@Override
	public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
		tooltip.add(Component.translatable(this.loreKey).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
	}
}
