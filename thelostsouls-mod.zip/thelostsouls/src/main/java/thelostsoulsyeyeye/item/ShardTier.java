package thelostsoulsyeyeye.item;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import thelostsoulsyeyeye.registry.ModItems;

/** Tool material for the Shardblade: a touch better than diamond, brittle in spirit. */
public enum ShardTier implements Tier {
	INSTANCE;

	@Override
	public int getUses() {
		return 1100;
	}

	@Override
	public float getSpeed() {
		return 8.0F;
	}

	@Override
	public float getAttackDamageBonus() {
		return 3.0F;
	}

	@Override
	public int getLevel() {
		return 3;
	}

	@Override
	public int getEnchantmentValue() {
		return 20;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.of(ModItems.SKY_SHARD);
	}
}
