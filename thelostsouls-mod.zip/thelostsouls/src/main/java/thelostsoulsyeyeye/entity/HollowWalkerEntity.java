package thelostsoulsyeyeye.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import thelostsoulsyeyeye.registry.ModSounds;

/**
 * The most common of Them: a tall, stooped husk. Slow-looking, but it lunges in short bursts of speed
 * when it gets close, so running in a straight line is not as safe as it looks.
 */
public class HollowWalkerEntity extends CorruptedEntity {
	private static final double BASE_SPEED = 0.26D;
	private static final double LUNGE_SPEED = 0.40D;
	private int lungeTicks;

	public HollowWalkerEntity(EntityType<? extends HollowWalkerEntity> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createCorruptedAttributes(28.0D, BASE_SPEED, 6.0D, 64.0D);
	}

	@Override
	public boolean isThem() {
		return true;
	}

	@Override
	protected int rollFeatures(RandomSource random) {
		int allowed = Deformity.MISSING_ARM_L | Deformity.MISSING_ARM_R | Deformity.MISSING_LEG | Deformity.RIBS
				| Deformity.HANGING_JAW | Deformity.EXTRA_ARM | Deformity.SECOND_HEAD;
		return Deformity.roll(random, allowed, 1, 3);
	}

	@Override
	public void aiStep() {
		super.aiStep();
		if (this.level().isClientSide) {
			return;
		}
		AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
		if (speed == null) {
			return;
		}
		if (this.lungeTicks > 0) {
			this.lungeTicks--;
			if (this.lungeTicks == 0) {
				speed.setBaseValue(BASE_SPEED);
			}
		} else if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) < 144.0D && this.random.nextInt(80) == 0) {
			this.lungeTicks = 18;
			speed.setBaseValue(LUNGE_SPEED);
		}
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ModSounds.ENTITY_HOLLOW_WALKER_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.ENTITY_HOLLOW_WALKER_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.ENTITY_HOLLOW_WALKER_DEATH;
	}

	@Override
	protected SoundEvent getAttackSound() {
		return ModSounds.ENTITY_HOLLOW_WALKER_ATTACK;
	}
}
