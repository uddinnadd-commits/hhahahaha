"""Environment, item, block, particle and HUD textures."""
from common import *
from scipy.ndimage import gaussian_filter

TAU = math.pi * 2


def grid(n_w, n_h=None):
    n_h = n_h or n_w
    y, x = np.mgrid[0:n_h, 0:n_w].astype(np.float32)
    return x, y


def to_img(rgba_float):
    return Image.fromarray(clamp8(rgba_float * 255.0), "RGBA")


# --------------------------------------------------------------------------------------
def solid():
    save_png(Image.new("RGBA", (4, 4), (255, 255, 255, 255)), "environment/solid.png")


def draw_cracks(size, rng, branches=11):
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    c = size / 2

    def walk(x, y, ang, length, width, depth):
        pts = [(x, y)]
        step = 6 + rng.random() * 6
        n = max(2, int(length / step))
        for i in range(n):
            ang += rng.normal(0, 0.28)
            x += math.cos(ang) * step
            y += math.sin(ang) * step
            pts.append((x, y))
            if depth < 3 and rng.random() < 0.13:
                side = rng.choice([-1, 1])
                walk(x, y, ang + side * (0.5 + rng.random() * 0.7), length * (0.4 + rng.random() * 0.25) * (1 - i / n),
                     max(1, width - 1), depth + 1)
        for i in range(len(pts) - 1):
            w = max(1, int(width * (1 - 0.6 * i / len(pts))))
            d.line([pts[i], pts[i + 1]], fill=255, width=w)

    for i in range(branches):
        ang = TAU * i / branches + rng.normal(0, 0.15)
        walk(c, c, ang, size * 0.5 * (0.85 + 0.3 * rng.random()), 4, 0)
    # spider-web rings around the impact point
    for r in (0.06, 0.13, 0.23, 0.36):
        a = rng.random() * TAU
        end = a + TAU
        pts = []
        while a < end:
            rr = size * r * (1 + rng.normal(0, 0.03))
            pts.append((c + math.cos(a) * rr, c + math.sin(a) * rr))
            a += 0.15 + rng.random() * 0.2
        for i in range(len(pts) - 1):
            if rng.random() > 0.22:
                d.line([pts[i], pts[i + 1]], fill=255, width=2)
    return mask


def sky_cracks():
    rng = np.random.default_rng(7)
    size = 512
    mask = draw_cracks(size, rng)
    m = np.asarray(mask, dtype=np.float32) / 255.0
    halo = gaussian_filter(m, 6)
    halo = np.clip(halo * 3.2, 0, 1)
    glow = np.clip(gaussian_filter(m, 2.2) * 2.4, 0, 1)
    violet = np.array([0.72, 0.45, 1.0], dtype=np.float32)
    white = np.array([1.0, 0.96, 1.0], dtype=np.float32)
    rgb = violet[None, None, :] * glow[..., None]
    rgb = rgb * (1 - m[..., None]) + white[None, None, :] * m[..., None]
    alpha = np.clip(np.maximum(np.maximum(halo * 0.62, glow * 0.95), m), 0, 1)
    out = np.dstack([rgb, alpha])
    save_png(to_img(out), "environment/sky_cracks.png")


def sky_void():
    rng = np.random.default_rng(3)
    n = 256
    x, y = grid(n)
    dx, dy = (x - n / 2) / (n / 2), (y - n / 2) / (n / 2)
    r = np.sqrt(dx ** 2 + dy ** 2)
    th = np.arctan2(dy, dx)
    edge = 0.52 + 0.06 * np.sin(th * 5 + 1) + 0.05 * np.sin(th * 11 + 2) + 0.03 * np.sin(th * 23) + rng.normal(0, 0.004, th.shape)
    inside = np.clip((edge - r) / 0.02, 0, 1)
    outer_glow = np.clip(1 - (r - edge) / 0.30, 0, 1) ** 2.2 * (r >= edge)
    core = np.clip(1 - (edge - r) / 0.16, 0, 1) * inside
    rgb = np.dstack([0.25 * core + 0.55 * outer_glow, 0.0 * core + 0.02 * outer_glow, 0.05 * core + 0.18 * outer_glow])
    alpha = np.clip(inside + outer_glow * 0.85, 0, 1)
    save_png(to_img(np.dstack([rgb, alpha])), "environment/sky_void.png")


def eye_textures():
    W, H = 256, 128
    x, y = grid(W, H)
    dx, dy = (x - W / 2) / (W / 2), (y - H / 2) / (H / 2)
    lid = 0.78 * np.clip(1 - np.abs(dx) ** 1.7, 0, 1) ** 0.75   # almond half-height
    inside = (np.abs(dy) < lid)
    border = (np.abs(dy) < lid) & (np.abs(dy) > lid - 0.10)
    rng = np.random.default_rng(5)
    sclera = np.dstack([np.full_like(dx, 0.87), np.full_like(dx, 0.80), np.full_like(dx, 0.70)])
    # red veins creeping in from the corners
    veins = np.zeros_like(dx)
    img = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(img)
    for side in (-1, 1):
        for _ in range(16):
            px, py = W / 2 + side * W * 0.5, H / 2 + rng.normal(0, 8)
            for _s in range(int(rng.integers(12, 34))):
                nx = px - side * (2 + rng.random() * 3)
                ny = py + rng.normal(0, 2.0)
                d.line([px, py, nx, ny], fill=255, width=1)
                px, py = nx, ny
    veins = np.asarray(img, dtype=np.float32) / 255.0
    sclera = sclera * (1 - veins[..., None] * 0.8) + np.array([0.62, 0.05, 0.07]) * veins[..., None] * 0.8
    ir = np.sqrt((dx * 2.0) ** 2 + (dy / 0.95) ** 2)   # iris radius (x is twice as wide)
    iris_mask = ir < 0.62
    iris_t = np.clip(ir / 0.62, 0, 1)
    iris = np.dstack([0.78 - 0.5 * iris_t, 0.28 - 0.25 * iris_t, 0.04 + 0.02 * iris_t])
    base = np.where(iris_mask[..., None], iris, sclera)
    base = np.where(border[..., None], np.array([0.10, 0.0, 0.04]), base)
    # shade toward the lids
    shade = 1 - 0.6 * (np.abs(dy) / np.maximum(lid, 1e-3)) ** 3
    base = base * np.clip(shade, 0.25, 1)[..., None]
    alpha = np.clip((lid - np.abs(dy)) / 0.03, 0, 1) * inside
    save_png(to_img(np.dstack([base, alpha])), "environment/eye.png")

    # pupil: vertical slit with a bloody rim
    S = 128
    x, y = grid(S)
    dx, dy = (x - S / 2) / (S / 2), (y - S / 2) / (S / 2)
    e = (dx / 0.20) ** 2 + (dy / 0.92) ** 2
    slit = np.clip((1 - e) / 0.06, 0, 1)
    rim = np.clip(1 - np.abs(e - 1.15) / 0.5, 0, 1) * (e >= 1)
    rgb = np.dstack([0.55 * rim, 0.02 * rim, 0.04 * rim])
    alpha = np.clip(np.maximum(slit, rim * 0.8), 0, 1)
    save_png(to_img(np.dstack([rgb, alpha])), "environment/eye_pupil.png")


def dark_sun():
    n = 256
    rng = np.random.default_rng(9)
    x, y = grid(n)
    dx, dy = (x - n / 2) / (n / 2), (y - n / 2) / (n / 2)
    r = np.sqrt(dx ** 2 + dy ** 2)
    th = np.arctan2(dy, dx)
    rays = 0.5 + 0.5 * np.sin(th * 17 + 3 * np.sin(th * 3)) * np.sin(th * 7)
    disc = np.clip((0.36 - r) / 0.012, 0, 1)
    corona = np.clip(1 - (r - 0.36) / (0.6 + 0.2 * rays), 0, 1) ** 2.5 * (r >= 0.36)
    rgb = np.dstack([0.94 * corona + 0.0 * disc, 0.86 * corona, 1.0 * corona])
    alpha = np.clip(disc + corona * 0.9, 0, 1) * np.clip((1 - r) / 0.05, 0, 1)
    save_png(to_img(np.dstack([rgb, alpha])), "environment/dark_sun.png")


def sky_swirl():
    n = 512
    rng = np.random.default_rng(21)
    x, y = grid(n)
    u, v = x / n, y / n
    # domain-warped marbling
    f1 = fbm(n, n, rng, 128, 4)
    f2 = fbm(n, n, rng, 64, 4)
    w = np.sin((u * 3 + f1 * 2.5) * TAU) * np.sin((v * 3 + f2 * 2.5) * TAU)
    m = np.clip(0.5 + 0.5 * w, 0, 1)
    c1 = np.array([0.55, 0.05, 0.22])
    c2 = np.array([0.18, 0.02, 0.35])
    rgb = c2[None, None, :] * (1 - m[..., None]) + c1[None, None, :] * m[..., None]
    alpha = np.clip(0.15 + 0.7 * (f1 * 0.6 + m * 0.4), 0, 0.9)
    save_png(to_img(np.dstack([rgb, alpha])), "environment/sky_swirl.png")


def tile_noise(n, rng, terms=7, maxk=4):
    y, x = np.mgrid[0:n, 0:n].astype(np.float32) / n
    out = np.zeros((n, n), dtype=np.float32)
    for _ in range(terms):
        kx, ky = rng.integers(-maxk, maxk + 1, 2)
        out += rng.random() * np.sin(TAU * (kx * x + ky * y) + rng.random() * TAU)
    out -= out.min()
    return out / max(out.max(), 1e-6)


def tentacle():
    n = 64
    rng = np.random.default_rng(31)
    t = tile_noise(n, rng)
    base = np.array([0.24, 0.12, 0.20], dtype=np.float32)
    rgb = base[None, None, :] * (0.55 + 0.9 * t[..., None])
    img = to_img(np.dstack([rgb, np.ones((n, n), dtype=np.float32)]))
    d = ImageDraw.Draw(img)
    # rows of suckers, wrapped for tiling
    for (cx, cy) in ((16, 16), (48, 16), (0, 48), (32, 48), (64, 48)):
        for ox in (-n, 0, n):
            for oy in (-n, 0, n):
                x0, y0 = cx + ox, cy + oy
                d.ellipse([x0 - 6, y0 - 6, x0 + 6, y0 + 6], fill=(150, 92, 120, 255))
                d.ellipse([x0 - 4, y0 - 4, x0 + 4, y0 + 4], fill=(70, 22, 40, 255))
                d.ellipse([x0 - 2, y0 - 2, x0 + 2, y0 + 2], fill=(190, 40, 80, 255))
    # glowing veins
    for k in range(3):
        xs = 8 + k * 21
        for yy in range(n):
            xx = int(xs + 3 * math.sin(yy / n * TAU * 2 + k)) % n
            d.point((xx, yy), fill=(255, 70, 120, 255))
    save_png(img, "environment/tentacle.png")


def shard_textures():
    n = 64
    x, y = grid(n)
    u, v = x / n, y / n
    rng = np.random.default_rng(41)
    grad = 0.35 + 0.65 * (u * 0.7 + (1 - v) * 0.3)
    streak = np.clip(np.sin((u + v) * 14 + rng.random() * 3) * 0.5 + 0.5, 0, 1) ** 6
    edge = np.minimum(np.minimum(u, 1 - u), np.minimum(v, 1 - v))
    edge_l = np.clip(1 - edge / 0.07, 0, 1)
    rgb = np.dstack([0.62 + 0.38 * streak + 0.3 * edge_l, 0.82 + 0.18 * streak + 0.2 * edge_l, np.ones_like(u)])
    alpha = np.clip(0.28 + 0.28 * grad + 0.5 * streak + 0.6 * edge_l, 0, 0.95)
    save_png(to_img(np.dstack([np.clip(rgb, 0, 1), alpha])), "environment/shard.png")

    # particle sprite (16x16)
    p = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(p)
    d.polygon([(8, 0), (14, 6), (11, 15), (4, 12), (2, 5)], fill=(190, 225, 255, 170), outline=(255, 255, 255, 255))
    d.line([(8, 2), (7, 12)], fill=(255, 255, 255, 220))
    d.line([(5, 6), (11, 8)], fill=(255, 255, 255, 140))
    save_png(p, "particle/glass_shard.png")


def vignette():
    n = 128
    x, y = grid(n)
    dx, dy = (x - n / 2) / (n / 2), (y - n / 2) / (n / 2)
    r = np.sqrt(dx ** 2 + dy ** 2) / 1.2
    a = np.clip((r - 0.45) / 0.55, 0, 1) ** 1.7
    rgb = np.dstack([0.28 * np.ones_like(a), 0.0 * np.ones_like(a), 0.02 * np.ones_like(a)])
    save_png(to_img(np.dstack([rgb, a])), "misc/vignette.png")


# --------------------------------------------------------------------------------------
# items / blocks (16x16 pixel art, drawn with PIL so the palette stays hand-picked)
def px(img, pts, color):
    for p in pts:
        if 0 <= p[0] < img.width and 0 <= p[1] < img.height:
            img.putpixel(p, color)


def item_textures():
    # sky shard
    s = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(s)
    d.polygon([(8, 1), (12, 5), (11, 13), (6, 14), (3, 7)], fill=(150, 205, 245, 235), outline=(235, 250, 255, 255))
    d.polygon([(8, 3), (10, 6), (9, 11), (7, 11), (6, 7)], fill=(205, 235, 255, 255))
    d.line([(8, 2), (7, 12)], fill=(255, 255, 255, 255))
    px(s, [(4, 8), (11, 7), (6, 13)], (255, 255, 255, 255))
    save_png(s, "item/sky_shard.png")

    # memory fragment: a pale wisp trapped in a cracked orb
    m = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(m)
    d.ellipse([2, 2, 13, 13], fill=(30, 36, 60, 255), outline=(120, 150, 210, 255))
    d.ellipse([5, 5, 10, 10], fill=(150, 220, 255, 255))
    d.ellipse([6, 6, 9, 9], fill=(235, 250, 255, 255))
    d.line([(9, 2), (7, 6), (9, 8), (6, 13)], fill=(10, 12, 24, 255))
    px(m, [(3, 4), (12, 11), (4, 11)], (180, 210, 255, 255))
    save_png(m, "item/memory_fragment.png")

    # shardblade
    b = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for i in range(11):
        x, y = 14 - i, 1 + i
        b.putpixel((x, y), (235, 250, 255, 255))
        if x - 1 >= 0:
            b.putpixel((x - 1, y), (140, 200, 240, 255))
        if x + 1 < 16:
            b.putpixel((x + 1, y), (70, 120, 180, 255))
    px(b, [(15, 0), (14, 0), (15, 1)], (255, 255, 255, 255))
    d = ImageDraw.Draw(b)
    d.line([(2, 9), (6, 13)], fill=(70, 40, 100, 255), width=1)       # guard
    d.line([(1, 14), (4, 11)], fill=(90, 62, 40, 255), width=1)      # grip
    px(b, [(0, 15), (1, 15)], (150, 120, 200, 255))                    # pommel
    save_png(b, "item/shardblade.png")


def block_textures():
    rng = np.random.default_rng(51)

    def stone(base, var=7):
        n = rng.normal(0, var, (16, 16, 1))
        arr = np.array(base, dtype=np.float32)[None, None, :] + n
        return Image.fromarray(clamp8(arr)).convert("RGBA")

    side = stone((34, 34, 46))
    d = ImageDraw.Draw(side)
    for yy in (0, 5, 10):
        d.line([(0, yy), (15, yy)], fill=(14, 14, 20, 255))
    for xx in (3, 11):
        d.line([(xx, 0), (xx, 15)], fill=(14, 14, 20, 255))
    d.line([(7, 1), (7, 14)], fill=(90, 200, 240, 255))
    px(side, [(6, 7), (8, 7), (6, 8), (8, 8)], (50, 120, 160, 255))
    save_png(side, "block/memory_cache_side.png")

    bottom = stone((22, 22, 30))
    save_png(bottom, "block/memory_cache_bottom.png")

    top = stone((38, 38, 52))
    d = ImageDraw.Draw(top)
    d.rectangle([1, 1, 14, 14], outline=(14, 14, 20, 255))
    d.ellipse([3, 3, 12, 12], outline=(90, 200, 240, 255))
    d.ellipse([6, 6, 9, 9], fill=(190, 240, 255, 255))
    px(top, [(7, 2), (7, 13), (2, 7), (13, 7)], (190, 240, 255, 255))
    save_png(top, "block/memory_cache_top.png")

    top_open = stone((30, 30, 40))
    d = ImageDraw.Draw(top_open)
    d.rectangle([1, 1, 14, 14], outline=(14, 14, 20, 255))
    d.ellipse([3, 3, 12, 12], outline=(40, 60, 76, 255), fill=(8, 8, 12, 255))
    px(top_open, [(7, 7), (8, 8)], (60, 90, 110, 255))
    save_png(top_open, "block/memory_cache_top_open.png")


def mod_icon():
    n = 128
    rng = np.random.default_rng(61)
    x, y = grid(n)
    dx, dy = (x - n / 2) / (n / 2), (y - n / 2) / (n / 2)
    r = np.sqrt(dx ** 2 + dy ** 2)
    q = np.clip(1 - r, 0, 1)
    bg = np.dstack([0.10 + 0.25 * q ** 2, 0.02 + 0.03 * q, 0.14 + 0.2 * q ** 1.5, np.ones_like(r)])
    base = to_img(np.clip(bg, 0, 1))
    cr = Image.open(os.path.join(ASSETS, "textures/environment/sky_cracks.png")).resize((n, n), Image.LANCZOS)
    base.alpha_composite(cr)
    eye = Image.open(os.path.join(ASSETS, "textures/environment/eye.png")).resize((96, 48), Image.LANCZOS)
    pup = Image.open(os.path.join(ASSETS, "textures/environment/eye_pupil.png")).resize((40, 40), Image.LANCZOS)
    base.alpha_composite(eye, (16, 40))
    base.alpha_composite(pup, (44, 44))
    ensure(os.path.join(ASSETS, "icon.png"))
    base.save(os.path.join(ASSETS, "icon.png"))


def build_all():
    solid()
    sky_cracks()
    sky_void()
    eye_textures()
    dark_sun()
    sky_swirl()
    tentacle()
    shard_textures()
    vignette()
    item_textures()
    block_textures()
    mod_icon()
    print("  environment / item / block / particle textures done")


if __name__ == "__main__":
    build_all()
